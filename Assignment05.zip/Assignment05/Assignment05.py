#    Defining variables
lsttodo=[]      # the list which contain all lines of todo.txt, each item of this list is dic with tow key(Task, Priority)
dicrow={}       #temp dic variable to make dictionary of todo list for each item of the dictodo
newlst=[]        #temp tuple to compare the final dictodo with the one in our text file for saving new revision
line=[]          #temp list to get each line of todo.txt in the loop
i={}             #temp dic variable to get each item of the list
FileName="todo.txt"   #Our text file name
fh=[]                   # file handler to open a file

fh=open(FileName, "r")

for line in fh:
    dicrow={}
    items=line.split(",")
    dicrow["Task"]=items[0].strip()
    dicrow["Priority"]=items[1].strip()
    lsttodo.append(dicrow)
#newlst=tuple(lsttodo)# copy the list od tasks to new list for comparing.


# while loop to ask user for options for processing data
while(True):

    print("""
    Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
    """)
    choice = input("Please Enter your Option from the above list to Perform:")
    if choice=="1":
        print("--Current To do List are:--")
        print("Task,Priority")
        print("----------------------------")
        for i in lsttodo:
            print(i["Task"]+","+i["Priority"])

    #--------Add new task--------------------------------

    elif choice=="2":
        Newtask=input("Please enter new task:")
        Newpriority=input("Please Enter your Task Priroty(low/high):").lower()
        dicrow={}
        dicrow["Task"] = Newtask
        dicrow["Priority"] = Newpriority
        lsttodo.append(dicrow)
        #print current todo list after adding new task
        print("--Current To do List are:--")
        print("Task,Priority")
        print("----------------------------")
        for i in lsttodo:
            print(i["Task"] + "," + i["Priority"])

         #--------Remove item.-----------------------

    elif choice=="3":
        RemTask=input("Which Task Would Like to Remove?")
        BlItemRemove=False
        for i in lsttodo:
          if i["Task"].lower()==RemTask.lower():
              lsttodo.remove(i)
              BlItemRemove=True
        if BlItemRemove==True:
            print("Item was removed.")
        else:print("Sorry, I could not find that task.")
        #Print todo list after removing task
        print("--Current To do List are:--")
        print("Task,Priority")
        print("---------------")
        for i in lsttodo:
            print(i["Task"] + "," + i["Priority"])

    #---------save item in todo.txt----------------
    elif choice=="4":
        fh=open(FileName,"w")
        for i in lsttodo:
           fh.write(i["Task"]+","+i["Priority"]+"\n")
        fh.close()
        print("Your Data all saved to todo.txt")
    #-----------Exit from programm---------
    elif choice =="5":
        # check if data in file is the same as data in our list(lsttodo)
        # if "no", then ask if user want to save data
        # else without saving exit the program
        fh = open(FileName, "r")
        for line in fh:
            dicrow = {}
            items = line.split(",")
            dicrow["Task"] = items[0].strip()
            dicrow["Priority"] = items[1].strip()
            newlst.append(dicrow)
        fh.close()
        if(lsttodo!=newlst):
            StrExit=input("Do You Want to Save Your Data Before Exiting Program(y/n)").lower()
            while StrExit not in ("y", "n"):
                print("Please Enter (y/n).")
                StrExit = input("Do You Want to Save Your Data Before Exiting Program(y/n)").lower()
            if StrExit=="y":
                fh = open(FileName, "w")
                for i in lsttodo:
                    fh.write(i["Task"] + "," + i["Priority"] + "\n")
                fh.close()
                print("Your Data All Saved in the Text Tile Called todo.txt")
                break
            else:
                print("You will be missed all your data, but previous data still exist in text file")
                print("Thanks For Using This Program.")
                break

        else:
            print("You already have all your data saved in text file")
            print("Thanks For Using This Program.")
            break
    #-----any entry other than in the list
    else:
        print("You Entered a Wrong Option, Please try again.")
        continue

fh.close()





