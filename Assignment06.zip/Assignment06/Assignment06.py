# -------------------------------------------------#
# Title: Working with Function and Classes
# Dev:   NBahadoran
# Date:  Nov 12, 2018
#Desc: This program is loading some to do list and processes data according to what user choose from menu of options
# ChangeLog: (Who, When, What)
#   NBahadoran, 11/12/2018, Write the first Version.
# -------------------------------------------------#


#-------------    Defining variables     -----------------

FileName="todo.txt"   #Our text file name, It is golabl variable

#-------------     Processing Part       ------------------

class InputOutput(object):
    """This class contain methods for input/Output of data"""
    @staticmethod
    def PrintMenu():
        """print the Menu of Options"""
        print("""
            Menu of Options
                1) Show current data
                2) Add a new item.
                3) Remove an existing item.
                4) Save Data to File
                5) Exit Program
                """)

    def AskQuestion(question):
        """Ask Question"""
        response = input(question)
        return response

    def Ask_yes_no(question):
        """Ask a yes or no question."""
        response = None
        while response not in ("y", "n"):
            response = InputOutput.AskQuestion(question).lower()
        return response

class TodoListProcess(object):
    """ This calss process all data in the To Do List"""
    @staticmethod
    def PrintCurrentData(lsttodo):
        """Print Current Data"""
        print("--Current To do List Tasks are:--")
        print("Task      ,              Priority")
        print("----------------------------------")
        for i in lsttodo:
            print(i["Task"] + "," + i["Priority"])

    def LoadDataFromFile(FileName):
        fh = open(FileName, "r")
        lsttodo=[]
        for line in fh:
            dicrow={}
            items=line.split(",")
            dicrow["Task"]=items[0].strip()
            dicrow["Priority"]=items[1].strip()
            lsttodo.append(dicrow)
        fh.close()
        return lsttodo

    def AddData(lsttodo,AddingTask,TaskPriority):
        """Adding Data into Current List"""
        dicrow = {}
        dicrow["Task"] = AddingTask.strip()
        dicrow["Priority"] = TaskPriority.strip()
        lsttodo.append(dicrow)
        return lsttodo

    def RemoveData(lsttodo,DelTask):
        """Removing Data from Current List"""
        BlItemRemove = False
        for i in lsttodo:
            if i["Task"].lower() == DelTask.lower():
                lsttodo.remove(i)
                BlItemRemove = True
        if BlItemRemove == True:
            print("Item was removed.")
        else:
            print("Sorry, I could not find that task.")
        return lsttodo

    def SaveDataToFile(lsttodo):
        """Save Current List in file called todo.txt"""
        fh = open(FileName, "w")
        for i in lsttodo:
            fh.write(i["Task"] + "," + i["Priority"] + "\n")
        fh.close()
        print("Your Data all saved to todo.txt")

# ----------------- Main Part of Program   --------------------------
def main():
    CurrentToDoLst=TodoListProcess.LoadDataFromFile(FileName)

        # while loop to ask user for options for processing data
    while(True):
        InputOutput.PrintMenu()
        choice = InputOutput.AskQuestion("Please Enter your Option from the above list to Perform:")
        if choice=="1":
            TodoListProcess.PrintCurrentData(CurrentToDoLst)
        #--------Add new task--------------------------------
        elif choice=="2":
            NewTask=InputOutput.AskQuestion("Please Enter New Task to Add in To Do List:")
            NewPriority=InputOutput.AskQuestion("Please Enter your Task Priroty(low/high):")
            CurrentToDoLst=TodoListProcess.AddData(CurrentToDoLst,NewTask,NewPriority)
            TodoListProcess.PrintCurrentData(CurrentToDoLst)
             #--------Remove item.-----------------------
        elif choice=="3":
            RemTask=InputOutput.AskQuestion("Which Task Would Like to Remove?").strip()
            CurrentToDoLst=TodoListProcess.RemoveData(CurrentToDoLst,RemTask)
            TodoListProcess.PrintCurrentData(CurrentToDoLst)
        #---------save item in todo.txt----------------
        elif choice=="4":
            StrSave=InputOutput.Ask_yes_no("Do You want to Save Your Data into the Text File Called todo.txt?(y/n)")
            if StrSave=="y":
                TodoListProcess.SaveDataToFile(CurrentToDoLst)
            else:
                print("You will be missed all your data, but previous data still exist in text file")
        #-----------Exit from programm---------
        elif choice =="5":
            # check if data in file is the same as data in our list(lsttodo)
            # if "no", then ask if user want to save data
            # else without saving exit the program
            newlst=TodoListProcess.LoadDataFromFile(FileName)
            if(CurrentToDoLst!=newlst):
                StrExit=InputOutput.Ask_yes_no("Do You Want to Save Your Data Before Exiting Program(y/n)")
                if StrExit=="y":
                    TodoListProcess.SaveDataToFile(CurrentToDoLst)
                    print("Your Data All Saved in the Text File Called todo.txt")
                    break
                else:
                    print("You will be missed all your data, but previous data still exist in text file")
                    print("Thanks For Using This Program.")
                    break
            else:
                print("You already have all your data saved in the text file")
                print("Thanks For Using This Program.")
                break
        #-----any entry other than in the list
        else:
            print("You Entered a Wrong Option, Please try again.")
            continue

main()


