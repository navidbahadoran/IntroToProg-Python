# Ask You user to enter Two No. Then calculate Sum, Difference, Product, and Quotient
import sys
def InputNo():
    "This Function ask user to enter two numbers"
    try:
        FirstNo=int(input("Enter First No: "))
        SecondNo=int(input("Enter Second No:"))
    except Exception as e:
        print("You Enter Wrong data.", e)
        print("Please Enter only No.")
        sys.exit()
    else:
        return FirstNo,SecondNo
#Sum Calculation
def Sum(Val1,Val2):
    "This function Calculate Sum of two No."
    return Val1+Val2
#Difference Calculation
def Difference(Val1,Val2):
    "This function Calculate Difference of two No."
    return Val1-Val2
#Product Calculation
def Product(Val1,Val2):
    "This function Calculate Difference of two No."
    return Val1*Val2
#Division Calculation
def Division(Val1,Val2):
    "This function Calculate Difference of two No."
    try:
        Quotient=Val1/Val2
    except Exception as e:
        print("Division cannot be performed.",e)
    else:
        return Quotient

def main():
    "Main part of the program is going to be performed"
    No1,No2=InputNo()
    print("Sum of ",No1,"and",No2,"is:",Sum(No1,No2))
    print("Difference of ", No1, "and", No2, "is:", Difference(No1, No2))
    print("Product of ", No1, "and", No2, "is:", Product(No1, No2))
    print("Quotient of ",No1,"and",No2,"is:",Division(No1,No2))
#Main
main()


